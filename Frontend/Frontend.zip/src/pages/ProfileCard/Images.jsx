const images = [
  {
    src: 'https://i.redd.it/b9j6xy1h659a1.jpg',
    description: 'Description for Image 1',
    projectDesc: 'The project will focus on [define the boundaries and limitations of the project]. This includes [mention any specific areas, features, or functionalities that will be included or excluded].',
  },
  {
    src: 'https://pbs.twimg.com/profile_images/1520598468494073856/shF3gmIP_400x400.jpg',
    description: 'Description for Image 2',
    projectDesc: 'Project Description 2',
  },
  {
    src: 'https://michaelhoweely.com/wp-content/uploads/2022/07/DALL%C2%B7E-2022-06-23-20.32.11-Two-astronauts-exploring-the-dark-cavernous-interior-of-a-huge-derelict-spacecraft-digital-art-1024x1024.png',
    description: 'Description for Image 3',
    projectDesc: 'Project Description 3',
  },
  {
    src: 'https://assets-global.website-files.com/642d50b04b2a5a614dc18e83/651a59ecf016ae2090ef7f39_Dalle-3%2020%20prompts.jpeg',
    description: 'Description for Image 4',
    projectDesc: 'Project Description 4',
  },
  {
    src: 'https://res.cloudinary.com/dwkvlhuyv/image/upload/v1698090829/zldgewtwzbpx8wls3ihe.jpg',
    description: 'Description for Image 4',
    projectDesc: 'Project Description 4',
  }
];

export default images;
